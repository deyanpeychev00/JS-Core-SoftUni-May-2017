/**
 * Created by Deyan Peychev on 14-Aug-17.
 */
let pageController = (() => {

    function displayCatalog(ctx) {
        auth.checkStatus(ctx);

        appService.getAllPosts()
            .then(function (posts) {
                let rank = 1;
                posts = posts.map(p => {
                    p.timePosted = appService.calcTime(p._kmd.ect);
                    p.rank = rank++;
                    p.isAuthor = p.author === localStorage.getItem('username');
                    return p;
                });

                ctx.publications = posts;

                body = '././templates/user/posts/view-posts/catalog.hbs';
                appService.commonPartials['post'] = '././templates/user/posts/view-posts/post.hbs';
                appService.commonPartials['body'] = body;
                ctx.loadPartials(appService.commonPartials).then(function () {

                    this.partial('././templates/page.hbs').then(function () {
                        $('a#deletePost').click(function (e) {
                            let postId = $(e.target).attr('data-id');
                            appService.deletePost(postId)
                                .then(function () {
                                    auth.showInfo('Post deleted.');
                                    displayCatalog(ctx);
                                })
                        })
                    })
                })
            })
            .catch(auth.handleError);
    }

    function getHome(ctx) {
        auth.checkStatus(ctx);
        let body = '';

        if (auth.isAuthed()) {
            displayCatalog(ctx);

        } else {
            body = '././templates/user/init.hbs';
            appService.commonPartials['body'] = body;
            ctx.loadPartials(appService.commonPartials).then(function () {

                this.partial('././templates/page.hbs')
            })
        }
    }

    function getSubmit(ctx) {
        auth.checkStatus(ctx);

        appService.commonPartials['body'] = '././templates/user/posts/submit.hbs';
        ctx.loadPartials(appService.commonPartials).then(function () {

            this.partial('././templates/page.hbs')
        })
    }

    function postSubmit(ctx) {
        let {url, title, image, comment} = ctx.params;

        let req = {
            "author": localStorage.getItem('username'),
            "title": title,
            "description": comment,
            "url": url,
            "imageUrl": image
        };

        appService.postLink(req)
            .then(function (res) {
                auth.showInfo('Successfully posted the link.');
                displayCatalog(ctx);
            })
            .catch(auth.handleError);
    }

    function displayComments(ctx, id) {
        auth.checkStatus(ctx);

        let linkID = (ctx.params.id).substr(1);

        if(linkID === ''){
            linkID = id;
        }

        appService.getSpecifiedPost(linkID)
            .then(function (post) {
                appService.getPostComments(linkID)
                    .then(function (comments) {
                        // handle post response
                        post.timePosted = appService.calcTime(post._kmd.ect);
                        post.isAuthor = post.author === localStorage.getItem('username');
                        ctx.publications = [post];

                        //handle comments response
                        comments = comments.map(c => {
                            c.timePosted = appService.calcTime(c._kmd.ect);
                            c.postIsAuthed = c.author === localStorage.getItem('username') || post.author === localStorage.getItem('username');
                            return c;
                        });
                        ctx.comments = comments;

                        //render page
                        appService.commonPartials['publication'] = '././templates/user/posts/view-comments/publication.hbs';
                        appService.commonPartials['body'] = '././templates/user/posts/view-comments/comments.hbs';
                        appService.commonPartials['comment'] = '././templates/user/posts/view-comments/comment.hbs';

                        ctx.loadPartials(appService.commonPartials).then(function () {
                            this.partial('././templates/page.hbs').then(function () {
                                $('a#deleteComment').click(function (e) {
                                    let commentId = $(e.target).attr('data-id');
                                   appService.deleteComment(commentId)
                                       .then(function (res) {
                                           auth.showInfo('Delete successful.');
                                           displayComments(ctx);
                                       })
                                       .catch(auth.handleError);
                                });
                                $('a#deletePost').click(function (e) {
                                    let postId = $(e.target).attr('data-id');
                                    appService.deletePost(postId)
                                        .then(function () {
                                            auth.showInfo('Post deleted.');
                                            displayCatalog(ctx);
                                        })
                                })
                            })
                        });
                    })
                    .catch(auth.handleError);
            })
            .catch(auth.handleError);
    }

    function submitComment(ctx) {
        let postId = $('.post').attr('data-id');
        let req = {
            "postId": postId,
            "content": ctx.params.content,
            "author": localStorage.getItem('username')
        };

        appService.postComment(req)
            .then(function (res) {
                auth.showInfo('Comment successfully posted.');
                displayComments(ctx, postId);
            })
            .catch(auth.handleError);
    }

    function login(req) {
        let {username, password} = req.params;
        console.log(username, password);
        auth.login(username, password)
            .then(function (res) {
                auth.showInfo('Logged in');
                auth.saveSession(res); // res === user info
                getHome(req);
            })
            .catch(auth.handleError);
    }

    function register(ctx) {
        let {username, password, repeatPass} = ctx.params;

        auth.register(username, password, repeatPass)
            .then(function (res) {
                auth.saveSession(res);
                auth.showInfo('Register successful');
                getHome(ctx);
            })
            .catch(auth.handleError);
    }

    function logout(ctx) {

        auth.logout()
            .then(function () {
                localStorage.clear();
                auth.showInfo('Logged out');
                getHome(ctx);
            })
            .catch(auth.handleError);
    }

    function displayEdit(ctx) {
        auth.checkStatus(ctx);
        let postId = (ctx.params.id).substr(1);
        appService.getSpecifiedPost(postId)
            .then(function (post) {

                ctx.editForm = post;

                appService.commonPartials['body'] = '././templates/user/posts/edit-post/edit.hbs';
                appService.commonPartials['editForm'] = '././templates/user/posts/edit-post/edit-form.hbs';

                ctx.loadPartials(appService.commonPartials).then(function () {
                    this.partial('././templates/page.hbs');
                })
            })
    }

    return {
        getHome,
        login,
        register,
        logout,
        displayCatalog,
        getSubmit,
        postSubmit,
        displayComments,
        submitComment,
        displayEdit
    }
})();