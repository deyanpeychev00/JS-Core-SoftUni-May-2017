function startApp() {
}